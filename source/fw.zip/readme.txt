- set code generation to multithreaded (+debug if desired)
- set entry point to entry

- download http://oss.sgi.com/projects/ogl-sample/ABI/glext.h , put in GL subdir of compiler's include dir
- add dir containing tex.h etc. to the compiler's include path

- leave out debug* for now (requires dbghelp, included with vc7)
- leave out memcpy.cpp, unless processor pack installed (not currently used anyway)
